package com.example.recorder;

public class view {
}
